/*
 * STP_TIM.h
 *
 *  Created on: Jan 13, 2026
 *      Author: pcmas
 */
#include <stdint.h>

#ifndef INC_STP_TIM_H_
#define INC_STP_TIM_H_

#include <stdint.h>

typedef enum { STEPPER_DIR_FWD = 0, STEPPER_DIR_REV = 1 } stepper_dir_t;

typedef void (*stepper_step_cb_t)(stepper_dir_t dir, int32_t steps);

void Stepper_RegisterStepCallback(stepper_step_cb_t cb);

/* Motion commands */
void Stepper_Move(stepper_dir_t dir, int32_t steps);
void Stepper_AddSteps(int32_t delta);
void Stepper_RequestReverse(int32_t steps_after_reverse);
void Stepper_SetStopDistance(int32_t steps_to_stop);
void Stepper_Abort(void);

/* Status */
uint8_t       Stepper_IsActive(void);
int32_t       Stepper_GetRemaining(void);
stepper_dir_t Stepper_GetDir(void);


#endif /* INC_STP_TIM_H_ */
