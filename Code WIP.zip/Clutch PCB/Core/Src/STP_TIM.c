/*
 * STP_TIM.c
 *
 *  Created on: Jan 13, 2026
 *      Author: ChatGPT lol
 */

#include "STP_TIM.h"
#include "main.h"
#include "tim.h"
#include <stdint.h>



#define ARR_START       20000
#define ARR_MIN         2897
#define ARR_STEP        60

#define K_STEPS         10
#define DECEL_STEPS     400


static volatile int32_t  steps_remaining     = 0;
static volatile int32_t  arr_current         = ARR_START;
static volatile uint8_t  motion_active       = 0;

static volatile stepper_dir_t current_dir    = STEPPER_DIR_FWD;
static volatile uint8_t  reverse_pending     = 0;
static volatile int32_t  reverse_steps       = 0;
static volatile int32_t  stop_distance_steps = 400;

static stepper_step_cb_t step_cb = 0;



static inline void Stepper_ApplyTim8PeriodAndDuty(int32_t arr)
{
    if (arr < 2) arr = 2;
    __HAL_TIM_SET_AUTORELOAD(&htim8, (uint32_t)arr);
    __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, ((uint32_t)arr + 1U) / 2U);
}

static inline void Stepper_SetDir(stepper_dir_t dir)
{
    HAL_GPIO_WritePin(Dir_GPIO_Port, Dir_Pin,
                      (dir == STEPPER_DIR_REV) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    current_dir = dir;
}

static inline void Stepper_StopAll_Internal(void)
{
    HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_2);
    HAL_TIM_OC_Stop_IT(&htim2, TIM_CHANNEL_1);
    motion_active = 0;
}




void Stepper_RegisterStepCallback(stepper_step_cb_t cb) { step_cb = cb; }

uint8_t Stepper_IsActive(void)     { return motion_active; }
int32_t Stepper_GetRemaining(void) { return steps_remaining; }
stepper_dir_t Stepper_GetDir(void) { return current_dir; }

void Stepper_SetStopDistance(int32_t steps_to_stop)
{
    if (steps_to_stop < 1) steps_to_stop = 1;
    __disable_irq();
    stop_distance_steps = steps_to_stop;
    __enable_irq();
}

void Stepper_Move(stepper_dir_t dir, int32_t steps)
{
    if (steps <= 0) return;


    if (motion_active)
    {
        Stepper_Abort();
        while (motion_active) { }
    }

    Stepper_SetDir(dir);

    __disable_irq();
    steps_remaining = steps;
    arr_current     = ARR_START;
    motion_active   = 1;
    reverse_pending = 0;
    __enable_irq();


    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint32_t)K_STEPS);
    __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC1);


    Stepper_ApplyTim8PeriodAndDuty(arr_current);

    HAL_TIM_OC_Start_IT(&htim2, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
}

void Stepper_AddSteps(int32_t delta)
{
    __disable_irq();
    int64_t tmp = (int64_t)steps_remaining + (int64_t)delta;
    if (tmp < 0) tmp = 0;
    steps_remaining = (int32_t)tmp;
    __enable_irq();
}

void Stepper_RequestReverse(int32_t steps_after_reverse)
{
    if (steps_after_reverse < 0) steps_after_reverse = 0;

    __disable_irq();
    reverse_pending = 1;
    reverse_steps   = steps_after_reverse;


    if (motion_active && steps_remaining > stop_distance_steps)
        steps_remaining = stop_distance_steps;

    __enable_irq();


    if (!motion_active)
    {
        stepper_dir_t new_dir = (current_dir == STEPPER_DIR_FWD) ? STEPPER_DIR_REV : STEPPER_DIR_FWD;
        Stepper_Move(new_dir, steps_after_reverse);
    }
}

void Stepper_Abort(void)
{
    __disable_irq();
    steps_remaining = 0;
    __enable_irq();
}

/* ---------------------- TIM2 OC CALLBACK ----------------------
   CubeMX provides TIM2_IRQHandler() -> HAL_TIM_IRQHandler(&htim2)
   HAL calls this on CC1 events for TIM2.
   Ensure there is ONLY ONE such callback in your project.
--------------------------------------------------------------- */
void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance != TIM2) return;
    if (htim->Channel  != HAL_TIM_ACTIVE_CHANNEL_1) return;
    if (!motion_active) return;


    int32_t consumed = (steps_remaining > (int32_t)K_STEPS) ? (int32_t)K_STEPS : steps_remaining;
    steps_remaining -= consumed;


    if (step_cb && consumed > 0) step_cb(current_dir, consumed);


    if (steps_remaining <= 0)
    {
        Stepper_StopAll_Internal();


        if (reverse_pending)
        {
            stepper_dir_t new_dir = (current_dir == STEPPER_DIR_FWD) ? STEPPER_DIR_REV : STEPPER_DIR_FWD;
            Stepper_SetDir(new_dir);

            int32_t new_steps;
            __disable_irq();
            new_steps = reverse_steps;
            reverse_pending = 0;
            __enable_irq();

            if (new_steps > 0)
            {
                __disable_irq();
                steps_remaining = new_steps;
                arr_current     = ARR_START;
                motion_active   = 1;
                __enable_irq();

                __HAL_TIM_SET_COUNTER(&htim2, 0);
                __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint32_t)K_STEPS);
                __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_CC1);

                Stepper_ApplyTim8PeriodAndDuty(arr_current);

                HAL_TIM_OC_Start_IT(&htim2, TIM_CHANNEL_1);
                HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
            }
        }
        return;
    }


    uint8_t force_decel = reverse_pending ? 1U : 0U;

    if (!force_decel && steps_remaining > (int32_t)DECEL_STEPS)
    {
        if (arr_current > (int32_t)ARR_MIN)
        {
            int32_t new_arr = arr_current - (int32_t)ARR_STEP;
            if (new_arr < (int32_t)ARR_MIN) new_arr = (int32_t)ARR_MIN;
            arr_current = new_arr;
        }
    }
    else
    {
        if (arr_current < (int32_t)ARR_START)
        {
            int32_t new_arr = arr_current + (int32_t)ARR_STEP;
            if (new_arr > (int32_t)ARR_START) new_arr = (int32_t)ARR_START;
            arr_current = new_arr;
        }
    }

    Stepper_ApplyTim8PeriodAndDuty(arr_current);


    uint32_t cnt  = __HAL_TIM_GET_COUNTER(&htim2);
    uint32_t next = __HAL_TIM_GET_COMPARE(&htim2, TIM_CHANNEL_1) + (uint32_t)K_STEPS;

    if (steps_remaining < (int32_t)K_STEPS)
        next = cnt + (uint32_t)steps_remaining;

    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, next);
}

