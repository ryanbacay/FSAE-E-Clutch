/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "comp.h"
#include "dac.h"
#include "fdcan.h"
#include "iwdg.h"
#include "opamp.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "STP_Driver.h"
#include <stdbool.h>
#include "STP_TIM.h"
#include "ee.h"
#include <stdint.h>
#include <math.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC5TIM 500
#define ADC2TIM 10

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint32_t delta = 0;
volatile uint32_t StepDelta = 0;
volatile int32_t StepperPosition = 0;
volatile uint32_t ClutchPosition = 0;
volatile uint32_t PaddlePosition = 0;
volatile uint32_t BitePosition = 0;
volatile bool UpdateSteps = 0;
volatile bool BiteFind = 0;
volatile bool StepChange = 0;
volatile bool DirChange = 0;
volatile stepper_dir_t Direction = 0;
stepper_dir_t desired = 0;
volatile uint8_t ADCFlag = 0; 		//0 for no change, 5 for adc5, 2 for adc2
uint16_t ADC5Buf = 0;
uint16_t ADC2Buf[2] = { 0 };
float ClutchDeg = 0;
float StepperDeg = 0;
float AngleDeg = 0;
uint64_t ADC5Timer[2] = { 0 };
uint64_t ADC2Timer[2] = { 0 };

typedef struct{
	uint32_t BitePos;
} eeStorage;

eeStorage ee;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_ADC_ConvtCpltCallback(ADC_HandleTypeDef *hadc) {
	if ((hadc->Instance == ADC5)) {
		ADCFlag = 5;
	}
	if ((hadc->Instance == ADC2)) {
		ADCFlag = 2;
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (GPIO_Pin == Fault_Pin) {
		Driver_Fault_Handle();
	}
	if (GPIO_Pin == User_Button_Pin) {
		__NOP();
	}
	if (GPIO_Pin == Bite_Find_Pin) {
		BiteFind =
				(HAL_GPIO_ReadPin(Bite_Find_GPIO_Port, Bite_Find_Pin)) ? 1 : 0;
		if (!(BiteFind)){ee_write();}
	}
}

static void Stepper_OnSteps(stepper_dir_t dir, int32_t steps) {

	if (dir == STEPPER_DIR_REV)
		StepperPosition += steps;
	else
		StepperPosition -= steps;
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_ADC2_Init();
	MX_COMP1_Init();
	MX_OPAMP1_Init();
	MX_OPAMP2_Init();
	MX_SPI2_Init();
	MX_DAC1_Init();
	MX_SPI3_Init();
	MX_TIM8_Init();
	MX_UART4_Init();
	MX_FDCAN1_Init();
	MX_TIM2_Init();
	MX_IWDG_Init();
	MX_ADC5_Init();
	MX_OPAMP5_Init();
	/* USER CODE BEGIN 2 */

	ee_init(&ee, sizeof(eeStorage));
	ee_read();

	HAL_DAC_Start(&hdac1, 1);
	for (int i = 0; i <= 744; i += 5) {
		HAL_DAC_SetValue(&hdac1, 1, DAC_ALIGN_12B_R, i);
		for (volatile int i = 0; i < 10000; i++) {
			__NOP(); // used to create less than millisecond delays, <time.h> cant be used easily on stm32
		}
	}
	HAL_DAC_SetValue(&hdac1, 1, DAC_ALIGN_12B_R, 745);


	Driver_Init();
	Stepper_RegisterStepCallback(Stepper_OnSteps);

	HAL_ADC_Start(&hadc5);
	ADC5Timer[0] = HAL_GetTick();
	ADC2Timer[0] = HAL_GetTick();
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		HAL_IWDG_Refresh(&hiwdg);
		ADC5Timer[1] = HAL_GetTick();
		ADC2Timer[1] = HAL_GetTick();

		switch (ADCFlag) {
		case 5:
			ClutchPosition = HAL_ADC_GetValue(&hadc5);
			if (BiteFind) {
				BitePosition = PaddlePosition;
			}
			ADCFlag = 0;
			break;
		case 2:
			for (int i = 0; i <= 1; i++) {
				ADC2Buf[i] = HAL_ADC_GetValue(&hadc2);
			}
			if (ADC2Buf[0] >= ADC2Buf[1]) {
				StepChange =
						((ADC2Buf[0] <= PaddlePosition * .99)
								|| (ADC2Buf[0] >= PaddlePosition * 1.01)) ?
								1 : 0;
				PaddlePosition =
						((PaddlePosition >= BitePosition * .9)
								&& (PaddlePosition <= BitePosition * 1.1)
								&& !(BiteFind)) ? BitePosition : ADC2Buf[0];
			} else {
				StepChange =
						((ADC2Buf[1] <= PaddlePosition * .99)
								|| (ADC2Buf[1] >= PaddlePosition * 1.01)) ?
								1 : 0;
				PaddlePosition = ADC2Buf[1];
				PaddlePosition =
						((PaddlePosition >= BitePosition * .9)
								&& (PaddlePosition <= BitePosition * 1.1)
								&& !(BiteFind)) ? BitePosition : ADC2Buf[1];
			}
			if (BiteFind) {
				BitePosition = PaddlePosition;
			}
			ADCFlag = 0;
			break;
		default:
			StepChange = 0;
			ADCFlag = 0;
			break;
		}

		if (PaddlePosition >= ClutchPosition) {
			desired = STEPPER_DIR_FWD;
			delta = PaddlePosition - ClutchPosition; // <-- check sign you actually want
		} else {
			desired = STEPPER_DIR_REV;
			delta = ClutchPosition - PaddlePosition;
		}
		DirChange = (Stepper_IsActive() && (desired != Stepper_GetDir()));
		Direction = desired;
		StepDelta = (uint32_t) roundf((delta * 60) / (1.8 * 360)); // converter from 12bit position to degree to stepper degree (60:1 ratio) to stepper steps (1.8 deg/step)

		if (!(Stepper_IsActive()) && (StepChange)) {
			Stepper_Move(Direction, StepDelta);
		} else if (StepChange) {
			if (DirChange) {
				Stepper_RequestReverse(StepDelta);
				DirChange = 0;
			} else {
				Stepper_AddSteps(StepDelta);
			}
		} else if ((StepperPosition >= PaddlePosition * .99)
				&& (StepperPosition <= PaddlePosition * 1.01)
				&& Stepper_IsActive()) {
			Stepper_Abort();
		}

		if ((ADC5Timer[1] - ADC5Timer[0]) >= ADC5TIM) {
			ADC5Timer[0] = ADC5Timer[1];
			HAL_ADC_Start_IT(&hadc5);

		}
		if ((ADC2Timer[1] - ADC2Timer[0]) >= ADC2TIM) {
			ADC2Timer[0] = ADC2Timer[1];
			HAL_ADC_Start_IT(&hadc2);
		}

		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI
			| RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV5;
	RCC_OscInitStruct.PLL.PLLN = 68;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK) {
		Error_Handler();
	}
	__HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL_SYSCLK);
	HAL_RCC_MCOConfig(RCC_MCO_PG10, RCC_MCO1SOURCE_PLLCLK, RCC_MCODIV_1);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
