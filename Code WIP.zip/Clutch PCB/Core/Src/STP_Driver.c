/*
 * STP_Driver.c
 *
 *  Created on: Jan 1, 2026
 *      Author: pcmas
 */
#include "main.h"
#include "spi.h"
#include "STP_Driver.h"
#include "iwdg.h"
#include <stdbool.h>
#define SPI_TIMEOUT 10

uint16_t ctrl[12] = {
		0x0000,				// filler entry so index matches registers
		0b0000010011001111, // ctrl1
		0b0000010100001000, // ctrl2
		0b0000011000111111, // ctrl3
		0b0000011101011001, // ctrl4
		0x0000,				// ctrl5 -- add tested stall
		0b0000100100100000, // ctrl6 -- add tested stall MSB to last 4
		0b0000110011011101, // ctrl9
		0b0000110100000000, // ctrl10
		0b0000111001000111, // ctrl11
		0b0000111110100000,	// ctrl12 -- add read reserved bits to last 3
		0b0001000000010010 	// ctrl13 -- add read reserved bits to last
		};



void Driver_Init() {
	bool resv = 0;
	uint16_t resvsize = 0;
	for (int i = 1; i <= 11; i++) {
		if (i == 10 || i == 11) {
			resv = 1;
			if (i == 10) {
				resvsize = 3;
			}
			if (i == 11) {
				resvsize = 1;
			}
		}
		Driver_Config_Confirm(&ctrl[i], resv, resvsize);
		resv = 0;
		resvsize = 0;
	}
	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 0);
	HAL_GPIO_WritePin(Green_GPIO_Port, Green_Pin, 1);
	HAL_Delay(100);
	HAL_GPIO_WritePin(Green_GPIO_Port, Green_Pin, 0);
	return;
}

void Driver_Config_Confirm(uint16_t *pData, bool resv, int resvsize) {
	uint16_t Tx = *pData;
	uint16_t TxData = Tx & 0x00FF;          // data byte we expect to read back
	uint16_t ReadTx = Tx | 0x4000;        // sets R/W bit for read (your scheme)
	uint16_t Rx;

	if (resv) {
		Rx = DRV_SpiXfer16(ReadTx);
		uint8_t rd = (uint8_t) (Rx & 0x00FF);   // register data byte

		if (resvsize == 1)
			Tx |= (rd & 0x01);
		else if (resvsize == 3)
			Tx |= (rd & 0x07);

		TxData = Tx & 0x00FF;
	}

	while (true) {
		(void) DRV_SpiXfer16(Tx);          // write
		Rx = DRV_SpiXfer16(ReadTx);       // read back same reg

		uint8_t status = (uint8_t) ((Rx >> 8) & 0xFF);
		uint8_t rd = (uint8_t) (Rx & 0xFF);

		(void) status;

		if (rd == (uint8_t) TxData)
			break;

		HAL_GPIO_WritePin(Green_GPIO_Port, Green_Pin, 0);
		HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 1);

	}
}

void Driver_Fault_Handle(void) {
	uint16_t TxFault = 0b0100000000000000;
	uint16_t TxFaultClear = 0b0000011010111111;
	uint8_t FAULT_MASK = 0b0000000010000000;

	uint16_t Rx;
	uint8_t status;
	bool otp = 0;

	HAL_GPIO_WritePin(Blue_GPIO_Port, Blue_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(Green_GPIO_Port, Green_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, GPIO_PIN_SET);

	uint32_t lastToggle = HAL_GetTick();
	uint32_t lastClear = lastToggle;

	while (1) {
		HAL_IWDG_Refresh(&hiwdg);
		uint32_t now = HAL_GetTick();

		Rx = DRV_SpiXfer16(TxFault);
		status = (uint8_t) (Rx >> 8);

		otp = (status & 0b00000010) ? 1 : 0;
		if (!(Rx & FAULT_MASK))
			break;

		if ((now - lastToggle) >= 300U) {
			lastToggle = now;
			HAL_GPIO_TogglePin(Red_GPIO_Port, Red_Pin);
			if (otp)
				HAL_GPIO_TogglePin(Green_GPIO_Port, Green_Pin);
		}

		if ((now - lastClear) >= 100) {
			lastClear = now;
			(void) DRV_SpiXfer16(TxFaultClear);
		}

		HAL_Delay(5);
	}

}

uint16_t DRV_SpiXfer16(uint16_t tx) {
	uint16_t rx = 0;
	for (volatile int i = 0; i < 90; i++) {
		__NOP();
	}
	HAL_GPIO_WritePin(Stepper_CS_GPIO_Port, Stepper_CS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi2, (uint8_t*) &tx, (uint8_t*) &rx, 1,
	SPI_TIMEOUT);
	HAL_GPIO_WritePin(Stepper_CS_GPIO_Port, Stepper_CS_Pin, 1);
	for (volatile int i = 0; i < 90; i++) {
		__NOP();
	}
	return rx;
}






























