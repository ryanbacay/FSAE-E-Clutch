/*
 * STP_Driver.c
 *
 *  Created on: Jan 1, 2026
 *      Author: pcmas
 */
#include "main.h"
#include "spi.h"
#include "STP_Driver.h"
#include "iwdg.h"
#include <stdbool.h>
#define SPI_TIMEOUT 10

/*
 * Driver register defaults.
 * Keep the validated current-limit setting at 0x47 for the 2.8 A motor.
 */
#define DRV_CTRL1_DATA   0xCFu
#define DRV_CTRL2_DATA   0x08u
#define DRV_CTRL3_DATA   0x3Fu
#define DRV_CTRL4_DATA   0x49u
#define DRV_CTRL5_DATA   0x00u
#define DRV_CTRL6_DATA   0x20u
#define DRV_CTRL9_DATA   0xD9u
#define DRV_CTRL10_DATA  0x00u
#define DRV_CTRL11_DATA  0x47u
#define DRV_CTRL12_DATA  0xA0u
#define DRV_CTRL13_DATA  0x12u

uint16_t ctrl[12] = {
		0x0000,				// filler entry so index matches registers
		(uint16_t)((0x04u << 8) | DRV_CTRL1_DATA),  // ctrl1
		(uint16_t)((0x05u << 8) | DRV_CTRL2_DATA),  // ctrl2
		(uint16_t)((0x06u << 8) | DRV_CTRL3_DATA),  // ctrl3
		(uint16_t)((0x07u << 8) | DRV_CTRL4_DATA),  // ctrl4
		(uint16_t)((0x08u << 8) | DRV_CTRL5_DATA),  // ctrl5
		(uint16_t)((0x09u << 8) | DRV_CTRL6_DATA),  // ctrl6
		(uint16_t)((0x0Cu << 8) | DRV_CTRL9_DATA),  // ctrl9
		(uint16_t)((0x0Du << 8) | DRV_CTRL10_DATA), // ctrl10
		(uint16_t)((0x0Eu << 8) | DRV_CTRL11_DATA), // ctrl11
		(uint16_t)((0x0Fu << 8) | DRV_CTRL12_DATA), // ctrl12
		(uint16_t)((0x10u << 8) | DRV_CTRL13_DATA)  // ctrl13
		};



void Driver_Init() {
	bool resv = 0;
	uint16_t resvsize = 0;
	for (int i = 1; i <= 11; i++) {
		if (i == 10 || i == 11) {
			resv = 1;
			if (i == 10) {
				resvsize = 3;
			}
			if (i == 11) {
				resvsize = 1;
			}
		}
		Driver_Config_Confirm(&ctrl[i], resv, resvsize);
		resv = 0;
		resvsize = 0;
	}
	//HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 1);
	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 0);

	return;

}

void Driver_Config_Confirm(uint16_t *pData, bool resv, int resvsize) {
	uint16_t Tx = *pData;
	uint16_t TxData = Tx & 0x00FF;          // data byte we expect to read back
	uint16_t ReadTx = Tx | 0x4000;        // sets R/W bit for read (your scheme)
	uint16_t Rx;

	if (resv) {
		Rx = DRV_SpiXfer16(ReadTx);
		uint8_t rd = (uint8_t) (Rx & 0x00FF);   // register data byte

		if (resvsize == 1)
			Tx |= (rd & 0x01);
		else if (resvsize == 3)
			Tx |= (rd & 0x07);

		TxData = Tx & 0x00FF;

	}
	uint32_t lastToggle = HAL_GetTick();
				uint32_t now;
	while (true) {
		now = HAL_GetTick();
		HAL_IWDG_Refresh(&hiwdg);
		(void) DRV_SpiXfer16(Tx);          // write
		HAL_Delay(10);
		Rx = DRV_SpiXfer16(ReadTx);       // read back same reg

		uint8_t rd = (uint8_t) (Rx & 0xFF);



		if (rd == (uint8_t) TxData)
			break;

		if ((now - lastToggle) >= 1000) {
					lastToggle = now;
					HAL_GPIO_TogglePin(Red_GPIO_Port, Red_Pin);

	}

}
}


void Driver_Fault_Handle(void) {
	uint16_t TxFault = 0b0100000000000000;
	uint16_t TxFaultClear = 0b0000011010111111;
	uint8_t FAULT_MASK = 0b0000000010000000;

	uint16_t Rx;

	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 0);

	uint32_t lastToggle = HAL_GetTick();
	uint32_t lastClear = lastToggle;

	while (1) {
		HAL_IWDG_Refresh(&hiwdg);
		uint32_t now = HAL_GetTick();

		Rx = DRV_SpiXfer16(TxFault);

		if (!(Rx & FAULT_MASK))
			break;

		if ((now - lastToggle) >= 300U) {
			lastToggle = now;
			HAL_GPIO_TogglePin(Red_GPIO_Port, Red_Pin);
		}

		if ((now - lastClear) >= 100) {
			lastClear = now;
			(void) DRV_SpiXfer16(TxFaultClear);
		}

		HAL_Delay(1);
	}
	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 1);


}

uint16_t DRV_SpiXfer16(uint16_t tx) {
	uint16_t rx = 0;
	for (volatile int i = 0; i < 90; i++) {
		__NOP();
	}
	HAL_GPIO_WritePin(Stepper_CS_GPIO_Port, Stepper_CS_Pin, 0);
	HAL_SPI_TransmitReceive(&hspi2, (uint8_t*) &tx, (uint8_t*) &rx, 1,
			SPI_TIMEOUT);
	HAL_GPIO_WritePin(Stepper_CS_GPIO_Port, Stepper_CS_Pin, 1);
	for (volatile int i = 0; i < 90; i++) {
		__NOP();
	}
	return rx;
}



























