/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "iwdg.h"
#include "opamp.h"
#include "rng.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "STP_Driver.h"
#include <stdbool.h>
#include "STP_TIM.h"
#include "ee.h"
#include <stdint.h>
#include <math.h>
#include "stdio.h"
#include "string.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_POLL_TIMEOUT_MS 2u
#define ADC_RUNTIME_PERIOD_MS 1u
#define ADC_RUNTIME_TIMEOUT_MS 10u
#define DEBUG_TX_BUFFER_SIZE 320u
#define TEMP_DISABLE_SENSOR_FAULT_DETECTION 1u

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

volatile uint32_t ClutchPosition = 0;
volatile uint32_t PaddlePosition = 0;
volatile uint16_t ADC2RuntimeBuf[2] = { 0u, 0u };
volatile uint16_t Paddle1Raw = 0;
volatile uint16_t Paddle2Raw = 0;
volatile uint16_t EncoderRaw = 0;
volatile uint8_t PaddleInputsInRange = 0u;
volatile uint8_t EncoderInRange = 0u;
volatile uint8_t StartupSensorReady = 0u;
volatile uint8_t STP_ControlInitialized = 0u;
volatile uint8_t PaddleConversionPending = 0u;
volatile uint8_t EncoderConversionPending = 0u;
volatile uint32_t LastPaddleSampleTick = 0u;
volatile uint32_t LastEncoderSampleTick = 0u;
volatile uint8_t DebugTxBusy = 0u;
volatile uint32_t ResetFlags = 0u;
volatile uint32_t FaultIrqCount = 0u;
volatile uint32_t BitePosition = 0;

volatile bool BiteFind = false;

volatile bool buttonflag = false;

extern volatile uint32_t dbg_wave_hz;
extern volatile uint32_t dbg_arr;
extern volatile uint16_t dbg_sps;
extern volatile float soft_clutch_deg;
extern volatile uint8_t STP_SensorFault;
extern volatile uint32_t STP_SensorFaultTrips;


typedef struct {
	uint32_t BitePos;
} eeStorage;

eeStorage ee;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
#if !TEMP_DISABLE_SENSOR_FAULT_DETECTION
static uint8_t SensorRawInRange(uint16_t raw, uint16_t min_raw, uint16_t max_raw);
#endif
static uint32_t SensorRemapToFullScale(uint16_t raw, uint16_t min_raw, uint16_t max_raw);
static uint8_t ReadPaddleRawPair(uint16_t *paddle1_raw, uint16_t *paddle2_raw);
static uint8_t ReadEncoderRaw(uint16_t *encoder_raw);
static void UpdateSensorState(uint16_t paddle1_raw, uint16_t paddle2_raw,
		uint16_t encoder_raw, uint8_t paddles_fresh, uint8_t encoder_fresh);
static uint8_t SampleAndUpdateSensors(void);
static uint8_t PrimeSensorsAtStartup(void);
static void StartRuntimeSensorAcquisition(void);
static void KickRuntimeSensorReads(uint32_t now);
static void UpdateRuntimeSensorState(uint32_t now);
static void TryQueueDebugTelemetry(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void UART_int(int num) {

	char buffer[100];
	sprintf(buffer, "%d\r\n", num);
	(void) HAL_UART_Transmit(&huart4, (uint8_t*) buffer, strlen(buffer), 100);

}

uint32_t RNG_Get12(void) {
	uint32_t random32;

	if (HAL_RNG_GenerateRandomNumber(&hrng, &random32) == HAL_OK) {
		return random32 & 0b111111111111;
	}

	return 0;
}

void blink() {
	uint32_t lastToggle = HAL_GetTick();
	while (true) {
		HAL_IWDG_Refresh(&hiwdg);
		uint32_t now = HAL_GetTick();
		if ((now - lastToggle) >= 100) {
			lastToggle = now;
			HAL_GPIO_TogglePin(Red_GPIO_Port, Red_Pin);
		}
	}
}

#if !TEMP_DISABLE_SENSOR_FAULT_DETECTION
static uint8_t SensorRawInRange(uint16_t raw, uint16_t min_raw, uint16_t max_raw) {
	uint16_t lo = (min_raw < max_raw) ? min_raw : max_raw;
	uint16_t hi = (min_raw > max_raw) ? min_raw : max_raw;

	return (uint8_t) ((raw >= lo) && (raw <= hi));
}
#endif

static uint32_t SensorRemapToFullScale(uint16_t raw, uint16_t min_raw,
		uint16_t max_raw) {
	float span = (float) ((int32_t) max_raw - (int32_t) min_raw);
	float norm;

	if (span == 0.0f) {
		return 0u;
	}

	norm = ((float) ((int32_t) raw - (int32_t) min_raw)) / span;

	if (norm < 0.0f) {
		norm = 0.0f;
	} else if (norm > 1.0f) {
		norm = 1.0f;
	}

	return (uint32_t) lroundf(norm * (float) STP_SENSOR_FULL_SCALE_COUNTS);
}

static uint8_t ReadPaddleRawPair(uint16_t *paddle1_raw, uint16_t *paddle2_raw) {
	if ((paddle1_raw == NULL) || (paddle2_raw == NULL)) {
		return 0u;
	}

	if (HAL_ADC_Start(&hadc2) != HAL_OK) {
		return 0u;
	}

	if (HAL_ADC_PollForConversion(&hadc2, ADC_POLL_TIMEOUT_MS) != HAL_OK) {
		(void) HAL_ADC_Stop(&hadc2);
		return 0u;
	}
	/* ADC2 rank 1 is Paddle2 (PC5), rank 2 is Paddle1 (PA1). */
	*paddle2_raw = (uint16_t) HAL_ADC_GetValue(&hadc2);

	if (HAL_ADC_PollForConversion(&hadc2, ADC_POLL_TIMEOUT_MS) != HAL_OK) {
		(void) HAL_ADC_Stop(&hadc2);
		return 0u;
	}
	*paddle1_raw = (uint16_t) HAL_ADC_GetValue(&hadc2);

	(void) HAL_ADC_Stop(&hadc2);
	return 1u;
}

static uint8_t ReadEncoderRaw(uint16_t *encoder_raw) {
	if (encoder_raw == NULL) {
		return 0u;
	}

	if (HAL_ADC_Start(&hadc5) != HAL_OK) {
		return 0u;
	}

	if (HAL_ADC_PollForConversion(&hadc5, ADC_POLL_TIMEOUT_MS) != HAL_OK) {
		(void) HAL_ADC_Stop(&hadc5);
		return 0u;
	}

	*encoder_raw = (uint16_t) HAL_ADC_GetValue(&hadc5);
	(void) HAL_ADC_Stop(&hadc5);
	return 1u;
}

static void UpdateSensorState(uint16_t paddle1_raw, uint16_t paddle2_raw,
		uint16_t encoder_raw, uint8_t paddles_fresh, uint8_t encoder_fresh) {
	Paddle1Raw = paddle1_raw;
	Paddle2Raw = paddle2_raw;
	EncoderRaw = encoder_raw;

#if TEMP_DISABLE_SENSOR_FAULT_DETECTION
	(void) paddles_fresh;
	(void) encoder_fresh;

	PaddleInputsInRange = 1u;
	EncoderInRange = 1u;
	StartupSensorReady = 1u;

	/* Temporary single-paddle mode: use only PA1 (Paddle1) for control. */
	PaddlePosition = SensorRemapToFullScale(paddle1_raw, STP_PADDLE1_RAW_MIN,
			STP_PADDLE1_RAW_MAX);
	ClutchPosition = SensorRemapToFullScale(encoder_raw, STP_ENCODER_RAW_MIN,
			STP_ENCODER_RAW_MAX);
#else
	{
		uint8_t paddle1_valid = SensorRawInRange(paddle1_raw,
				STP_PADDLE1_RAW_MIN, STP_PADDLE1_RAW_MAX);
		uint8_t encoder_valid = SensorRawInRange(encoder_raw, STP_ENCODER_RAW_MIN,
				STP_ENCODER_RAW_MAX);

		PaddleInputsInRange = (uint8_t) (paddles_fresh && paddle1_valid);
		EncoderInRange = (uint8_t) (encoder_fresh && encoder_valid);
		StartupSensorReady = (uint8_t) (PaddleInputsInRange && EncoderInRange);

		if (PaddleInputsInRange) {
			/* Temporary single-paddle mode: use only PA1 (Paddle1) for control. */
			PaddlePosition = SensorRemapToFullScale(paddle1_raw,
					STP_PADDLE1_RAW_MIN, STP_PADDLE1_RAW_MAX);
		}

		if (EncoderInRange) {
			ClutchPosition = SensorRemapToFullScale(encoder_raw,
					STP_ENCODER_RAW_MIN, STP_ENCODER_RAW_MAX);
		}
	}
#endif
}

static uint8_t SampleAndUpdateSensors(void) {
	uint16_t paddle1_raw = 0u;
	uint16_t paddle2_raw = 0u;
	uint16_t encoder_raw = 0u;

	if (!ReadPaddleRawPair(&paddle1_raw, &paddle2_raw)
			|| !ReadEncoderRaw(&encoder_raw)) {
#if TEMP_DISABLE_SENSOR_FAULT_DETECTION
		PaddleInputsInRange = 1u;
		EncoderInRange = 1u;
		StartupSensorReady = 1u;
		return 1u;
#else
		PaddleInputsInRange = 0u;
		EncoderInRange = 0u;
		StartupSensorReady = 0u;
		return 0u;
#endif
	}

	UpdateSensorState(paddle1_raw, paddle2_raw, encoder_raw, 1u, 1u);
	return StartupSensorReady;
}

static uint8_t PrimeSensorsAtStartup(void) {
	uint32_t start_tick;

	HAL_Delay(STP_SENSOR_STARTUP_SETTLE_MS);
	start_tick = HAL_GetTick();

	do {
		HAL_IWDG_Refresh(&hiwdg);
		if (SampleAndUpdateSensors()) {
			return 1u;
		}
		HAL_Delay(1u);
	} while ((HAL_GetTick() - start_tick) < STP_SENSOR_STARTUP_TIMEOUT_MS);

	return 0u;
}

static void StartRuntimeSensorAcquisition(void) {
	uint32_t now = HAL_GetTick();

	ADC2RuntimeBuf[0] = Paddle2Raw;
	ADC2RuntimeBuf[1] = Paddle1Raw;
	LastPaddleSampleTick = now;
	LastEncoderSampleTick = now;
	PaddleConversionPending = 0u;
	EncoderConversionPending = 0u;
}

static void KickRuntimeSensorReads(uint32_t now) {
	if ((PaddleConversionPending != 0u)
			&& ((now - LastPaddleSampleTick) > ADC_RUNTIME_TIMEOUT_MS)) {
		PaddleConversionPending = 0u;
	}

	if ((EncoderConversionPending != 0u)
			&& ((now - LastEncoderSampleTick) > ADC_RUNTIME_TIMEOUT_MS)) {
		EncoderConversionPending = 0u;
	}

	if (PaddleConversionPending == 0u) {
		if ((HAL_ADC_Start_DMA(&hadc1, (uint32_t*) ADC2RuntimeBuf, 2) == HAL_OK)&&(HAL_ADC_Start_DMA(&hadc2, (uint32_t*) ADC2RuntimeBuf, 2) == HAL_OK)) {
			PaddleConversionPending = 1u;
		}
	}

	if (EncoderConversionPending == 0u) {
		if (HAL_ADC_Start_IT(&hadc5) == HAL_OK) {
			EncoderConversionPending = 1u;
		}
	}
}

static void UpdateRuntimeSensorState(uint32_t now) {
	uint16_t paddle1_raw = Paddle1Raw;
	uint16_t paddle2_raw = Paddle2Raw;
	uint16_t encoder_raw = EncoderRaw;
	uint8_t paddles_fresh =
			(uint8_t) ((now - LastPaddleSampleTick) <= ADC_RUNTIME_TIMEOUT_MS);
	uint8_t encoder_fresh =
			(uint8_t) ((now - LastEncoderSampleTick) <= ADC_RUNTIME_TIMEOUT_MS);

	UpdateSensorState(paddle1_raw, paddle2_raw, encoder_raw, paddles_fresh,
			encoder_fresh);
}

static void TryQueueDebugTelemetry(void) {
	static char debug_tx_buffer[DEBUG_TX_BUFFER_SIZE];
	long target_cdeg;
	long meas_cdeg;
	uint32_t fault_pin_raw;
	int len;

	if (DebugTxBusy != 0u) {
		return;
	}

	target_cdeg = lroundf(STP_TargetDeg * 100.0f);
	meas_cdeg = lroundf(STP_MeasuredDeg * 100.0f);
	fault_pin_raw = (uint32_t) HAL_GPIO_ReadPin(Fault_GPIO_Port, Fault_Pin);
	len = snprintf(debug_tx_buffer, sizeof(debug_tx_buffer),
			"P1=%u P2=%u Cmd=%lu EncRaw=%u Enc=%lu PF=%u EF=%u SF=%u SFTrips=%lu FLT=%lu FIRQ=%lu RST=0x%08lX Target_cdeg=%ld Meas_cdeg=%ld SPS=%u EN=%u\r\n",
			(unsigned int) Paddle1Raw, (unsigned int) Paddle2Raw,
			(unsigned long) PaddlePosition, (unsigned int) EncoderRaw,
			(unsigned long) ClutchPosition, (unsigned int) !PaddleInputsInRange,
			(unsigned int) !EncoderInRange, (unsigned int) STP_SensorFault,
			(unsigned long) STP_SensorFaultTrips, (unsigned long) fault_pin_raw,
			(unsigned long) FaultIrqCount,
			(unsigned long) ResetFlags, target_cdeg, meas_cdeg, (unsigned int) STP_CurrentSPS,
			(unsigned int) STP_IsEnabled);

	if (len <= 0) {
		return;
	}

	if ((size_t) len >= sizeof(debug_tx_buffer)) {
		len = (int) (sizeof(debug_tx_buffer) - 1u);
	}

	DebugTxBusy = 1u;
	if (HAL_UART_Transmit_IT(&huart4, (uint8_t*) debug_tx_buffer,
			(uint16_t) len) != HAL_OK) {
		DebugTxBusy = 0u;
	}
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
	if (hadc->Instance == ADC1) {
		/* ADC2 rank 1 is Paddle2 (PC5), rank 2 is Paddle1 (PA1). */
		Paddle1Raw = (uint16_t) HAL_ADC_GetValue(&hadc1);
		LastPaddleSampleTick = HAL_GetTick();
		PaddleConversionPending = 0u;
	}
	if (hadc->Instance == ADC2) {
		/* ADC2 rank 1 is Paddle2 (PC5), rank 2 is Paddle1 (PA1). */
		Paddle2Raw = (uint16_t) HAL_ADC_GetValue(&hadc2);
		LastPaddleSampleTick = HAL_GetTick();
		PaddleConversionPending = 0u;
	}

	if (hadc->Instance == ADC5) {
		EncoderRaw = (uint16_t) HAL_ADC_GetValue(&hadc5);
		LastEncoderSampleTick = HAL_GetTick();
		EncoderConversionPending = 0u;
	}
}

void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc) {
	if (hadc->Instance == ADC2) {
		PaddleConversionPending = 0u;
	}

	if (hadc->Instance == ADC5) {
		EncoderConversionPending = 0u;
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart->Instance == UART4) {
		DebugTxBusy = 0u;
	}
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
	if (huart->Instance == UART4) {
		DebugTxBusy = 0u;
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (GPIO_Pin == Fault_Pin) {
		FaultIrqCount++;
		//Driver_Fault_Handle();
	}
	if (GPIO_Pin == User_Button_Pin) {

		HAL_GPIO_TogglePin(Red_GPIO_Port, Red_Pin);

//PaddlePosition = RNG_Get12();
//buttonflag = true;

	}
	if (GPIO_Pin == Bite_Find_Pin) {
		BiteFind = true;
	}
}

void HAL_SYSTICK_Callback(void) {
	if (STP_ControlInitialized) {
		STP_ServoUpdate_1ms();
	}
	HAL_IWDG_Refresh(&hiwdg);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC2_Init();
  MX_OPAMP1_Init();
  MX_OPAMP2_Init();
  MX_SPI2_Init();
  MX_DAC1_Init();
  MX_TIM8_Init();
  MX_UART4_Init();
  MX_TIM2_Init();
  MX_IWDG_Init();
  MX_ADC5_Init();
  MX_OPAMP5_Init();
  MX_RNG_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */



	//ee_init(&ee, sizeof(eeStorage));
	//ee_read();

  HAL_OPAMP_Start(&hopamp1);
  HAL_OPAMP_Start(&hopamp2);
  HAL_OPAMP_Start(&hopamp5);

	HAL_GPIO_WritePin(Red_GPIO_Port, Red_Pin, 1);
	HAL_DAC_Start(&hdac1, 1);

	DAC1->DHR12R1 = 749;

	(void) PrimeSensorsAtStartup();

	HAL_GPIO_WritePin(Sleep_GPIO_Port, Sleep_Pin, 1);
	Driver_Init();

	STP_SetHoldEnable(0u);
	STP_Init();
	StartRuntimeSensorAcquisition();
	STP_ControlInitialized = 1u;

	uint32_t lastSensorSample = HAL_GetTick();
	uint32_t lastTransmit = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {




		HAL_IWDG_Refresh(&hiwdg);

		uint32_t now = HAL_GetTick();
		if ((now - lastSensorSample) >= ADC_RUNTIME_PERIOD_MS) {
			lastSensorSample = now;
			KickRuntimeSensorReads(now);
			UpdateRuntimeSensorState(now);
		}

		if ((now - lastTransmit) >= 500) {
			lastTransmit = now;
			TryQueueDebugTelemetry();
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV5;
  RCC_OscInitStruct.PLL.PLLN = 68;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV4;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
