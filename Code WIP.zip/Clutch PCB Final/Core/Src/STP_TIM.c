/* ============================== STP_TIM.c ==============================
   Encoder-tracked clutch controller using TIM8 CH2 as STEP.
   - Target comes from the remapped paddle ADC counts
   - Measured position comes from the remapped encoder ADC counts
   - Driver is DISABLED at rest
   - Uses a simple bounded motion profile so 40 deg travel stays under 1 s
=========================================================================== */

#include "STP_TIM.h"
#include "main.h"
#include "tim.h"
#include <math.h>

extern volatile uint32_t ClutchPosition;
extern volatile uint32_t PaddlePosition;
extern volatile uint8_t PaddleInputsInRange;
extern volatile uint8_t EncoderInRange;
extern volatile uint8_t StartupSensorReady;

/* ---------------- Telemetry ---------------- */
volatile float STP_TargetDeg     = 0.0f;
volatile float STP_MeasuredDeg   = 0.0f;
volatile float STP_ErrorDeg      = 0.0f;
volatile uint32_t STP_CurrentSPS = 0u;
volatile uint8_t STP_IsEnabled   = 0u;
volatile uint8_t STP_Dir         = 1u;
volatile uint8_t STP_StallFault  = 0u;
volatile uint8_t STP_SensorFault = 0u;
volatile uint32_t STP_SensorFaultTrips = 0u;

volatile float soft_clutch_deg = 0.0f;

/* ---------------- Debug ---------------- */
volatile uint32_t dbg_desired_sps = 0u;
volatile uint32_t dbg_written_sps = 0u;
volatile uint32_t dbg_written_arr = 0u;
volatile uint32_t dbg_wave_hz     = 0u;

/* ---------------- Internal ---------------- */
static uint8_t hold_enable_in_deadband = 0u;
static uint8_t step_output_enabled     = 0u;

static uint8_t  dir_state      = 1u;
static uint16_t dir_lock_ms    = 0u;
static uint8_t  stopped_state  = 1u;
static uint8_t  motion_awake   = 0u;
static uint8_t  wake_delay_ms  = 0u;
static uint32_t programmed_step_sps = 0xFFFFFFFFu;
static uint32_t programmed_step_psc = 0xFFFFFFFFu;
static uint32_t programmed_step_arr = 0xFFFFFFFFu;
static uint8_t  stop_confirm_ms = 0u;
static uint8_t  wake_confirm_ms = 0u;
static uint8_t  speed_sweep_rising = 1u;
static uint8_t  speed_sweep_step_timer_ms = 0u;

static float cmd_vel_dps = 0.0f;
static float meas_filt_deg = 0.0f;
static float target_filt_deg = 0.0f;
static float target_hold_deg = 0.0f;

/* Local tuning */
#define STP_STOP_DEADBAND_DEG   1.10f
#define STP_WAKE_DEADBAND_DEG   1.50f

#define DIR_HYST_DEG            0.4f
#define DIR_LOCK_TIME_MS        0u
#define WAKE_DELAY_MS           1u
#define TARGET_FILTER_A_IDLE    0.08f
#define TARGET_FILTER_A_SETTLE  0.12f
#define TARGET_FILTER_A_ACTIVE  0.55f
#define TARGET_LATCH_DEG        0.35f
#define MEAS_FILTER_A_IDLE      0.10f
#define MEAS_FILTER_A_ACTIVE    0.35f
#define STOP_CONFIRM_MS         20u
#define WAKE_CONFIRM_MS         12u
#define STP_FINAL_HOLD_DEG      0.20f

#define STP_TRAJ_VEL_MAX_DPS        ((((float)STP_MAX_MOTOR_RPM) * 360.0f * (float)STP_GEAR_RATIO_DEN) / (60.0f * (float)STP_GEAR_RATIO_NUM))
#define STP_TRAJ_ACCEL_DPS2        420.0f
#define STP_TRAJ_DECEL_DPS2       1200.0f
#define STP_TRAJ_STOP_VEL_DPS        0.08f

#define STP_CREEP_ZONE_DEG           1.5f
#define STP_SLOW_ZONE_VEL_KP         6.0f

#define STP_SWEEP_MIN_SPS            10u
#define STP_SWEEP_STEP_SPS            1u
#define STP_SWEEP_STEP_PERIOD_MS      4u

#if STP_ENABLE_STALL_DETECT
static float last_meas_deg = 0.0f;
static uint16_t stall_ms_accum = 0u;
#endif

static inline float clampf(float x, float lo, float hi)
{
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static inline float slew_towardf(float current, float target, float max_delta)
{
    float delta = target - current;

    if (delta > max_delta) {
        delta = max_delta;
    } else if (delta < -max_delta) {
        delta = -max_delta;
    }

    return current + delta;
}

static inline float STP_SlewVelocityToward(float current, float target)
{
    float max_delta = STP_TRAJ_ACCEL_DPS2 * 0.001f;

    if ((current * target < 0.0f) || (fabsf(target) < fabsf(current))) {
        max_delta = STP_TRAJ_DECEL_DPS2 * 0.001f;
    }

    return slew_towardf(current, target, max_delta);
}

static inline void STP_SyncTrajectoryToMeasured(float meas_deg)
{
    cmd_vel_dps = 0.0f;
    meas_filt_deg = meas_deg;
    target_hold_deg = meas_deg;
    target_filt_deg = meas_deg;
}

static inline void STP_ResetVelocityState(void)
{
    cmd_vel_dps = 0.0f;
}

static inline void STP_ResetSettleDebounce(void)
{
    stop_confirm_ms = 0u;
    wake_confirm_ms = 0u;
}

static inline void STP_SetDir(uint8_t dir)
{
    HAL_GPIO_WritePin(Dir_GPIO_Port, Dir_Pin, dir ? GPIO_PIN_RESET : GPIO_PIN_SET);
    STP_Dir = dir;
}

static inline void STP_EnableDriver(uint8_t en)
{
    HAL_GPIO_WritePin(Enable_GPIO_Port, Enable_Pin, en ? GPIO_PIN_SET : GPIO_PIN_RESET);
    STP_IsEnabled = en;
}

static inline void STP_StepOutputEnable(uint8_t en)
{
    if (en) {
        if (!step_output_enabled) {
            htim8.Instance->EGR = TIM_EGR_UG;
            __HAL_TIM_SET_COUNTER(&htim8, 0u);
            HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
            __HAL_TIM_MOE_ENABLE(&htim8);
            step_output_enabled = 1u;
        }
    } else {
        if (step_output_enabled) {
            HAL_TIM_PWM_Stop(&htim8, TIM_CHANNEL_2);
            step_output_enabled = 0u;
        }
    }
}

static inline void STP_ResetMotionWakeState(void)
{
    motion_awake = 0u;
    wake_delay_ms = 0u;
}

static inline void STP_DisableMotionOutputs(void)
{
    STP_CurrentSPS = 0u;
    STP_StepOutputEnable(0u);
    STP_EnableDriver(0u);
    STP_ResetMotionWakeState();
}

static inline void STP_StopMotionForDirectionChange(void)
{
    uint8_t keep_awake = (uint8_t)(motion_awake || STP_IsEnabled);

    STP_CurrentSPS = 0u;
    STP_StepOutputEnable(0u);

    if (keep_awake) {
        STP_EnableDriver(1u);
        motion_awake = 1u;
        wake_delay_ms = 0u;
    } else {
        STP_EnableDriver(0u);
    }
}

static inline void STP_EnterIdleState(void)
{
    STP_CurrentSPS = 0u;
    STP_StepOutputEnable(0u);
    STP_EnableDriver(hold_enable_in_deadband ? 1u : 0u);
    STP_ResetMotionWakeState();
}

static inline float STP_ReadMeasuredDeg(void)
{
    float meas_deg = ((float)ClutchPosition / (float)STP_SENSOR_FULL_SCALE_COUNTS) * STP_OUTPUT_MAX_DEG;
    return clampf(meas_deg, STP_OUTPUT_MIN_DEG, STP_OUTPUT_MAX_DEG);
}

static inline float STP_FilterMeasuredDeg(float raw_meas_deg)
{
    float alpha = stopped_state ? MEAS_FILTER_A_IDLE : MEAS_FILTER_A_ACTIVE;

    meas_filt_deg += alpha * (raw_meas_deg - meas_filt_deg);
    return meas_filt_deg;
}

static inline uint32_t STP_GetActiveMinSPS(float abs_err_deg, float abs_cmd_vel_dps)
{
    if (abs_err_deg <= STP_FINAL_HOLD_DEG) {
        return 0u;
    }

    if ((abs_err_deg <= STP_STOP_DEADBAND_DEG) && (abs_cmd_vel_dps <= STP_TRAJ_STOP_VEL_DPS)) {
        return 0u;
    }

    if (abs_err_deg <= STP_CREEP_ZONE_DEG) {
        return STP_CREEP_SPS_MIN;
    }

    return STP_RUN_SPS_MIN;
}

static inline void STP_UpdateVelocityCommand(float err_deg)
{
    float desired_vel_mag = 0.0f;
    float abs_err_deg = fabsf(err_deg);

    if (abs_err_deg <= STP_FINAL_HOLD_DEG) {
        cmd_vel_dps = STP_SlewVelocityToward(cmd_vel_dps, 0.0f);
        return;
    }

    if ((abs_err_deg > STP_STOP_DEADBAND_DEG) || (fabsf(cmd_vel_dps) > STP_TRAJ_STOP_VEL_DPS)) {
        float remaining_deg = abs_err_deg - STP_STOP_DEADBAND_DEG;

        if (remaining_deg < 0.0f) {
            remaining_deg = 0.0f;
        }

        desired_vel_mag = sqrtf(2.0f * STP_TRAJ_ACCEL_DPS2 * remaining_deg);
        if (desired_vel_mag > STP_TRAJ_VEL_MAX_DPS) {
            desired_vel_mag = STP_TRAJ_VEL_MAX_DPS;
        }

        if (abs_err_deg <= STP_CREEP_ZONE_DEG) {
            float slow_zone_vel = STP_SLOW_ZONE_VEL_KP * abs_err_deg;
            if (desired_vel_mag > slow_zone_vel) {
                desired_vel_mag = slow_zone_vel;
            }
        }
    }

    {
        float desired_vel = 0.0f;

        if (desired_vel_mag > 0.0f) {
            desired_vel = (err_deg >= 0.0f) ? desired_vel_mag : -desired_vel_mag;
        }

        cmd_vel_dps = STP_SlewVelocityToward(cmd_vel_dps, desired_vel);
    }
}

static inline uint32_t STP_ComputeDesiredSPS(void)
{
    float desired_sps = fabsf(cmd_vel_dps) * STP_MICROSTEPS_PER_OUT_DEG;

    if (desired_sps > (float)STP_SPS_OPEN_LOOP_CAP) {
        desired_sps = (float)STP_SPS_OPEN_LOOP_CAP;
    }

    return (uint32_t)(desired_sps + 0.5f);
}

#if STP_ENABLE_STALL_DETECT
static inline void STP_ResetStallMonitor(float meas_deg)
{
    last_meas_deg = meas_deg;
    stall_ms_accum = 0u;
}
#endif

static inline void STP_SetStepRateSPS(uint32_t requested_sps)
{
    uint32_t sps_to_write = requested_sps;
    uint32_t prescaler;
    uint32_t arr;
    uint32_t period_ticks;
    uint64_t total_ticks;

    if (sps_to_write == 0u) {
        sps_to_write = 2u;
    }

    uint32_t wave_hz = (uint32_t)sps_to_write;
#if STP_COUNTS_BOTH_EDGES
    wave_hz /= 2u;
    if (wave_hz < 1u) wave_hz = 1u;
#endif

    if (wave_hz >= STP_TIM8_TICK_HZ) {
        wave_hz = STP_TIM8_TICK_HZ - 1u;
    }

    total_ticks = ((uint64_t)STP_TIM8_TICK_HZ + ((uint64_t)wave_hz / 2u))
            / (uint64_t)wave_hz;
    if (total_ticks < 2u) {
        total_ticks = 2u;
    }

    prescaler = (uint32_t) ((total_ticks + 65535u - 1u) / 65536u);
    if (prescaler == 0u) {
        prescaler = 1u;
    } else if (prescaler > 65536u) {
        prescaler = 65536u;
    }

    period_ticks = (uint32_t) ((total_ticks + ((uint64_t)prescaler / 2u))
            / (uint64_t)prescaler);
    if (period_ticks < 2u) {
        period_ticks = 2u;
    } else if (period_ticks > 65536u) {
        period_ticks = 65536u;
    }

    prescaler -= 1u;
    arr = period_ticks - 1u;

    if ((sps_to_write == programmed_step_sps)
            && (prescaler == programmed_step_psc)
            && (arr == programmed_step_arr)) {
        dbg_wave_hz = wave_hz;
        return;
    }

    __disable_irq();
    __HAL_TIM_SET_PRESCALER(&htim8, prescaler);
    __HAL_TIM_SET_AUTORELOAD(&htim8, arr);
    __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, period_ticks / 2u);
    __enable_irq();

    programmed_step_sps = sps_to_write;
    programmed_step_psc = prescaler;
    programmed_step_arr = arr;
    dbg_written_arr = arr;
    dbg_written_sps = sps_to_write;
    dbg_wave_hz = wave_hz;
}

#if STP_TEMP_SPEED_SWEEP_MODE
static inline void STP_RunSpeedSweep_1ms(void)
{
    uint32_t cur = STP_CurrentSPS;

    STP_TargetDeg = 0.0f;
    STP_MeasuredDeg = 0.0f;
    STP_ErrorDeg = 0.0f;

    STP_SetDir(1u);

    if (!motion_awake) {
        STP_EnableDriver(1u);
        STP_StepOutputEnable(0u);
        motion_awake = 1u;
        wake_delay_ms = WAKE_DELAY_MS;
        speed_sweep_step_timer_ms = 0u;
        STP_CurrentSPS = 0u;
        return;
    }

    if (wake_delay_ms > 0u) {
        wake_delay_ms--;
        STP_EnableDriver(1u);
        STP_StepOutputEnable(0u);
        speed_sweep_step_timer_ms = 0u;
        STP_CurrentSPS = 0u;
        return;
    }

    if (cur < STP_SWEEP_MIN_SPS) {
        cur = STP_SWEEP_MIN_SPS;
        speed_sweep_step_timer_ms = 0u;
    } else {
        speed_sweep_step_timer_ms++;

        if (speed_sweep_step_timer_ms >= STP_SWEEP_STEP_PERIOD_MS) {
            speed_sweep_step_timer_ms = 0u;

            if (speed_sweep_rising) {
                uint32_t next = (uint32_t)cur + STP_SWEEP_STEP_SPS;

                if (next >= STP_SPS_MAX) {
                    cur = STP_SPS_MAX;
                    speed_sweep_rising = 0u;
                } else {
                    cur = next;
                }
            } else {
                if (cur <= (STP_SWEEP_MIN_SPS + STP_SWEEP_STEP_SPS)) {
                    cur = STP_SWEEP_MIN_SPS;
                    speed_sweep_rising = 1u;
                } else {
                    cur -= STP_SWEEP_STEP_SPS;
                }
            }
        }
    }

    STP_CurrentSPS = cur;
    dbg_desired_sps = cur;

    STP_EnableDriver(1u);
    STP_SetStepRateSPS(cur);
    STP_StepOutputEnable(1u);
}
#endif

void STP_SetHoldEnable(uint8_t hold_enable)
{
    hold_enable_in_deadband = (hold_enable != 0u);
}

void STP_Init(void)
{
    float meas_deg = STP_ReadMeasuredDeg();

    /* Start fully stopped */
    STP_StepOutputEnable(0u);

    /* Ensure continuous mode */
    htim8.Instance->CR1 &= (uint16_t)~TIM_CR1_OPM;

    STP_SetDir(1u);
    STP_EnableDriver(0u);

    STP_CurrentSPS = 0u;
    STP_StallFault = 0u;
    STP_SensorFault = 0u;
    soft_clutch_deg = meas_deg;
    STP_TargetDeg = meas_deg;
    STP_MeasuredDeg = meas_deg;
    STP_ErrorDeg = 0.0f;

    dir_state = 1u;
    dir_lock_ms = 0u;
    stopped_state = 1u;
    motion_awake = 0u;
    wake_delay_ms = 0u;
    programmed_step_sps = 0xFFFFFFFFu;
    programmed_step_psc = 0xFFFFFFFFu;
    programmed_step_arr = 0xFFFFFFFFu;
    stop_confirm_ms = 0u;
    wake_confirm_ms = 0u;
    speed_sweep_rising = 1u;
    speed_sweep_step_timer_ms = 0u;
    cmd_vel_dps = 0.0f;
    meas_filt_deg = meas_deg;
    target_filt_deg = meas_deg;
    target_hold_deg = meas_deg;

#if STP_ENABLE_STALL_DETECT
    last_meas_deg = meas_deg;
    stall_ms_accum = 0u;
#endif

    STP_SetStepRateSPS(STP_CREEP_SPS_MIN);
}

void STP_ServoUpdate_1ms(void)
{
    if (STP_StallFault) {
        STP_DisableMotionOutputs();
        return;
    }

    if (!StartupSensorReady || !PaddleInputsInRange || !EncoderInRange) {
        float meas_deg = STP_ReadMeasuredDeg();

        if (STP_SensorFault == 0u) {
            STP_SensorFaultTrips++;
        }
        STP_SensorFault = 1u;
        STP_SyncTrajectoryToMeasured(meas_deg);
        STP_ResetVelocityState();
        STP_ResetSettleDebounce();
        stopped_state = 1u;
        soft_clutch_deg = meas_deg;
        STP_TargetDeg = meas_deg;
        STP_MeasuredDeg = meas_deg;
        STP_ErrorDeg = 0.0f;
        STP_DisableMotionOutputs();

#if STP_ENABLE_STALL_DETECT
        STP_ResetStallMonitor(meas_deg);
#endif
        return;
    }

    STP_SensorFault = 0u;

#if STP_TEMP_SPEED_SWEEP_MODE
    STP_RunSpeedSweep_1ms();
    return;
#endif

    /* Target from paddle ADC */
    float target_deg = ((float)PaddlePosition / (float)STP_SENSOR_FULL_SCALE_COUNTS) * STP_OUTPUT_MAX_DEG;
    target_deg = clampf(target_deg, STP_OUTPUT_MIN_DEG, STP_OUTPUT_MAX_DEG);

    /* Absolute encoder feedback */
    float raw_meas_deg = STP_ReadMeasuredDeg();
    float meas_deg = STP_FilterMeasuredDeg(raw_meas_deg);
    soft_clutch_deg = raw_meas_deg;

        float target_filter_a = TARGET_FILTER_A_ACTIVE;
        uint8_t latch_target = 0u;

        if (stopped_state) {
            target_filter_a = TARGET_FILTER_A_IDLE;
            latch_target = 1u;
        } else if (fabsf(target_hold_deg - meas_deg) <= STP_WAKE_DEADBAND_DEG) {
            target_filter_a = TARGET_FILTER_A_SETTLE;
            latch_target = 1u;
        }

        target_filt_deg += target_filter_a * (target_deg - target_filt_deg);

        if (latch_target) {
            if (fabsf(target_filt_deg - target_hold_deg) >= TARGET_LATCH_DEG) {
                target_hold_deg = target_filt_deg;
            }
        } else {
            target_hold_deg = target_filt_deg;
        }

    target_deg = target_hold_deg;

    STP_TargetDeg = target_deg;
    STP_MeasuredDeg = meas_deg;

    float err  = target_deg - meas_deg;
    float aerr = fabsf(err);
    uint8_t stop_condition;
    STP_ErrorDeg = err;
    STP_UpdateVelocityCommand(err);
    stop_condition = (uint8_t)((aerr <= STP_STOP_DEADBAND_DEG)
            && (fabsf(cmd_vel_dps) <= STP_TRAJ_STOP_VEL_DPS));

    /* Stop/wake hysteresis */
    if (stopped_state) {
        stop_confirm_ms = 0u;

        if (aerr <= STP_WAKE_DEADBAND_DEG) {
            wake_confirm_ms = 0u;
            STP_ResetVelocityState();
            STP_EnterIdleState();

#if STP_ENABLE_STALL_DETECT
            STP_ResetStallMonitor(meas_deg);
#endif
            return;
        }

        if (wake_confirm_ms < WAKE_CONFIRM_MS) {
            wake_confirm_ms++;
            STP_ResetVelocityState();
            STP_EnterIdleState();

#if STP_ENABLE_STALL_DETECT
            STP_ResetStallMonitor(meas_deg);
#endif
            return;
        }

        wake_confirm_ms = 0u;
        stopped_state = 0u;
    } else {
        wake_confirm_ms = 0u;

        if (stop_condition) {
            if (stop_confirm_ms < STOP_CONFIRM_MS) {
                stop_confirm_ms++;
            }
        } else {
            stop_confirm_ms = 0u;
        }

        if (stop_confirm_ms >= STOP_CONFIRM_MS) {
            stopped_state = 1u;
            STP_SyncTrajectoryToMeasured(meas_deg);
            STP_ResetSettleDebounce();
            STP_EnterIdleState();

#if STP_ENABLE_STALL_DETECT
            STP_ResetStallMonitor(meas_deg);
#endif
            return;
        }
    }

    /* Direction hysteresis */
        uint8_t want_dir = dir_state;
        float drive_cmd = err;

        if (fabsf(drive_cmd) < DIR_HYST_DEG) {
            drive_cmd = cmd_vel_dps;
        }

        if (drive_cmd >  DIR_HYST_DEG) want_dir = 1u;
        if (drive_cmd < -DIR_HYST_DEG) want_dir = 0u;

        if (want_dir != dir_state) {
            dir_state = want_dir;
            dir_lock_ms = DIR_LOCK_TIME_MS;

            STP_StopMotionForDirectionChange();
            STP_SetDir(dir_state);
            return;
        }

    /* Short reversal lock */
    if (dir_lock_ms > 0u) {
        dir_lock_ms--;
        STP_StopMotionForDirectionChange();
        return;
    }

    STP_SetDir(dir_state);

    /* Wake sequence:
       Enable driver first, wait a few ms, then begin stepping. */
    if (!motion_awake) {
        STP_EnableDriver(1u);
        STP_StepOutputEnable(0u);
        motion_awake = 1u;
        wake_delay_ms = WAKE_DELAY_MS;
        STP_CurrentSPS = 0u;
        return;
    }

    if (wake_delay_ms > 0u) {
        wake_delay_ms--;
        STP_EnableDriver(1u);
        STP_StepOutputEnable(0u);
        STP_CurrentSPS = 0u;
        return;
    }

    /* One slow, conservative acceleration ramp from position error to step rate. */
    uint32_t desired_sps = STP_ComputeDesiredSPS();
    uint32_t active_min_sps = STP_GetActiveMinSPS(aerr, fabsf(cmd_vel_dps));
    dbg_desired_sps = desired_sps;

    /* Ramp limit */
    uint32_t cur = STP_CurrentSPS;

    if (cur < desired_sps) {
        uint32_t inc = desired_sps - cur;
        if (inc > STP_ACCEL_SPS_PER_MS) inc = STP_ACCEL_SPS_PER_MS;
        cur += inc;
    } else {
        uint32_t dec = cur - desired_sps;
        if (dec > STP_DECEL_SPS_PER_MS) dec = STP_DECEL_SPS_PER_MS;
        cur -= dec;
    }

    if (cur > STP_SPS_MAX) cur = STP_SPS_MAX;
    if ((active_min_sps == 0u) && (desired_sps == 0u)) {
        cur = 0u;
    } else if (cur < active_min_sps) {
        cur = active_min_sps;
    }

    STP_CurrentSPS = cur;

    /* Apply motion */
    STP_EnableDriver(1u);
    STP_SetStepRateSPS(cur);
    STP_StepOutputEnable(1u);

#if STP_ENABLE_STALL_DETECT
    {
        float dmeas = fabsf(meas_deg - last_meas_deg);

        if (STP_CurrentSPS >= STP_STALL_MIN_SPS) {
            if (dmeas < 0.02f) {
                if (stall_ms_accum < 1000u) stall_ms_accum++;
            } else {
                stall_ms_accum = 0u;
            }

            if (stall_ms_accum >= STP_STALL_MAX_MS) {
                STP_StallFault = 1u;
                STP_DisableMotionOutputs();
            }
        } else {
            stall_ms_accum = 0u;
        }

        last_meas_deg = meas_deg;
    }
#endif
}
