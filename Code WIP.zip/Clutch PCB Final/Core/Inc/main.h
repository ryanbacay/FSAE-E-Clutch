/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define User_Button_Pin GPIO_PIN_13
#define User_Button_GPIO_Port GPIOC
#define User_Button_EXTI_IRQn EXTI15_10_IRQn
#define Bite_Find_Pin GPIO_PIN_15
#define Bite_Find_GPIO_Port GPIOC
#define Bite_Find_EXTI_IRQn EXTI15_10_IRQn
#define Encoder_IN_Pin GPIO_PIN_3
#define Encoder_IN_GPIO_Port GPIOC
#define Paddle1_IN_Pin GPIO_PIN_3
#define Paddle1_IN_GPIO_Port GPIOA
#define Boost_Voltage_Pin GPIO_PIN_4
#define Boost_Voltage_GPIO_Port GPIOA
#define Fan_Toggle_Pin GPIO_PIN_5
#define Fan_Toggle_GPIO_Port GPIOA
#define Paddle2_IN_Pin GPIO_PIN_7
#define Paddle2_IN_GPIO_Port GPIOA
#define Home_Pin GPIO_PIN_11
#define Home_GPIO_Port GPIOB
#define Home_EXTI_IRQn EXTI15_10_IRQn
#define Stepper_CS_Pin GPIO_PIN_12
#define Stepper_CS_GPIO_Port GPIOB
#define Motor_SCLK_Pin GPIO_PIN_13
#define Motor_SCLK_GPIO_Port GPIOB
#define Motor_MISO_Pin GPIO_PIN_14
#define Motor_MISO_GPIO_Port GPIOB
#define Motor_MOSI_Pin GPIO_PIN_15
#define Motor_MOSI_GPIO_Port GPIOB
#define Step_Pin GPIO_PIN_7
#define Step_GPIO_Port GPIOC
#define Fault_Pin GPIO_PIN_8
#define Fault_GPIO_Port GPIOC
#define Fault_EXTI_IRQn EXTI9_5_IRQn
#define Dir_Pin GPIO_PIN_8
#define Dir_GPIO_Port GPIOA
#define Enable_Pin GPIO_PIN_9
#define Enable_GPIO_Port GPIOA
#define Sleep_Pin GPIO_PIN_10
#define Sleep_GPIO_Port GPIOA
#define Red_Pin GPIO_PIN_4
#define Red_GPIO_Port GPIOB
#define Green_Pin GPIO_PIN_5
#define Green_GPIO_Port GPIOB
#define Blue_Pin GPIO_PIN_6
#define Blue_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
