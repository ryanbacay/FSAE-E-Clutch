/* ============================== STP_TIM.h ==============================
   Encoder-tracked clutch controller using TIM8 CH2 as STEP.
   - Target comes from the remapped paddle ADC counts
   - Measured position comes from the remapped encoder ADC counts
   - Motion is bounded to a 40 deg stroke with a 100 RPM motor cap

   IMPORTANT:
   - TIM8 clock is assumed 170 MHz
   - Driver counts BOTH rising and falling edges as steps
   - Commanded microstep is fixed at 1/64
=========================================================================== */

#ifndef __STP_TIM_H
#define __STP_TIM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define STP_COUNTS_BOTH_EDGES          1u
#define STP_MOTOR_FULL_STEPS_PER_REV   200u
#define STP_COMMAND_MICROSTEP          64u

#define STP_GEAR_RATIO_NUM             60u
#define STP_GEAR_RATIO_DEN             1u
#define STP_GEAR_RATIO                 ((float)STP_GEAR_RATIO_NUM / (float)STP_GEAR_RATIO_DEN)

#define STP_OUTPUT_TRAVEL_DEG          40u
#define STP_OUTPUT_MIN_DEG             0.0f
#define STP_OUTPUT_MAX_DEG             ((float)STP_OUTPUT_TRAVEL_DEG)
#define STP_SENSOR_FULL_SCALE_COUNTS   4095u

/*
 * Sensor raw ranges.
 * Update these values to the measured usable travel endpoints for the final hardware.
 * The code handles either increasing or decreasing sensors.
 */
#define STP_PADDLE1_RAW_MIN            0u
#define STP_PADDLE1_RAW_MAX            STP_SENSOR_FULL_SCALE_COUNTS
#define STP_PADDLE2_RAW_MIN            0u
#define STP_PADDLE2_RAW_MAX            STP_SENSOR_FULL_SCALE_COUNTS
#define STP_ENCODER_RAW_MIN            0u
#define STP_ENCODER_RAW_MAX            STP_SENSOR_FULL_SCALE_COUNTS

#define STP_SENSOR_STARTUP_SETTLE_MS   2u
#define STP_SENSOR_STARTUP_TIMEOUT_MS  100u

#define STP_MICROSTEPS_PER_MOTOR_REV   (STP_MOTOR_FULL_STEPS_PER_REV * STP_COMMAND_MICROSTEP)
#define STP_MICROSTEPS_PER_OUT_REV     ((STP_MICROSTEPS_PER_MOTOR_REV * STP_GEAR_RATIO_NUM) / STP_GEAR_RATIO_DEN)
#define STP_MICROSTEPS_PER_OUT_DEG     ((float)STP_MICROSTEPS_PER_OUT_REV / 360.0f)

/* Slow-mode test cap for bench tuning. */
#define STP_MAX_MOTOR_RPM              100u
#define STP_SPS_MAX                    ((STP_MAX_MOTOR_RPM * STP_MICROSTEPS_PER_MOTOR_REV) / 60u)
#define STP_SPS_OPEN_LOOP_CAP          STP_SPS_MAX
#define STP_TEMP_SPEED_SWEEP_MODE      0u
#define STP_SPS_STOP                   0u
#define STP_RUN_SPS_MIN               1200u
#define STP_CREEP_SPS_MIN              80u
#define STP_ACCEL_SPS_PER_MS         1000u
#define STP_DECEL_SPS_PER_MS         2600u

/* Full 40 deg travel on a 60:1 gearbox needs 10667 microsteps. */
#define STP_FULL_STROKE_MICROSTEPS     (((STP_OUTPUT_TRAVEL_DEG * STP_MICROSTEPS_PER_OUT_REV) + 359u) / 360u)
#define STP_FULL_STROKE_TIME_AT_MAX_MS (((STP_FULL_STROKE_MICROSTEPS * 1000u) + STP_SPS_MAX - 1u) / STP_SPS_MAX)

#define STP_ENABLE_STALL_DETECT        0u
#define STP_STALL_MIN_SPS              2000u
#define STP_STALL_MAX_MS               150u

#ifndef STP_TIM8_TICK_HZ
#define STP_TIM8_TICK_HZ               170000000u
#endif

extern volatile float STP_TargetDeg;
extern volatile float STP_MeasuredDeg;
extern volatile float STP_ErrorDeg;
extern volatile uint32_t STP_CurrentSPS;
extern volatile uint8_t STP_IsEnabled;
extern volatile uint8_t STP_Dir;
extern volatile uint8_t STP_StallFault;

extern volatile float soft_clutch_deg;
extern volatile uint8_t STP_SensorFault;

void STP_Init(void);
void STP_ServoUpdate_1ms(void);
void STP_SetHoldEnable(uint8_t hold_enable);

#ifdef __cplusplus
}
#endif

#endif
