/*
 * STP_Driver.h
 *
 *  Created on: Jan 1, 2026
 *      Author: pcmas
 */
#include <stdbool.h>

#ifndef INC_STP_DRIVER_H_
#define INC_STP_DRIVER_H_

void Driver_Init();
void Driver_Config_Confirm(uint16_t *pData,bool resv,int resvsize);
void Driver_Fault_Handle();
uint16_t DRV_SpiXfer16(uint16_t tx);


#endif /* INC_STP_DRIVER_H_ */
